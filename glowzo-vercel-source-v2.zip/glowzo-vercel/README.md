# Glowzo — Vercel-ready website

All product photos, the homepage cover, combo poster and three videos are
included in public/media. No Lovable media proxy is needed.

## Replace your existing Vercel deployment
1. Extract this ZIP.
2. Replace the website files in your GitHub repository with the contents of
   the glowzo-vercel folder (not the surrounding folder). Keep your repository's
   .git directory. Remove the old bun.lock if one exists.
3. In Vercel Project Settings → Build and Deployment, choose Framework Preset
   Other, Node.js 22.x, Build Command npm run build, Install Command npm install.
4. Clear any previous Output Directory override. Leave it unset; Nitro creates
   .vercel/output automatically. Do not select dist or .output/public.
5. Save, commit the replacement files, and redeploy without the old build cache.
6. Open the deployed homepage, Shop and a product page. Check the photos, play
   each video with sound, then add products and check the WhatsApp order.

No environment variables or paid media service are required for this website.
Your existing Vercel domain and custom-domain settings can stay unchanged.

## Run locally
Install Node.js 22.12 or newer, then run:

    npm install
    npm run dev

## Checks
    npm test
    npm run build

## Ordering
Orders go to WhatsApp +91 80759 81789. Shipping is ₹50 per nonempty cart.
The cart is temporary and does not store customer data or require accounts.

The contact email and policy wording were previously supplied as draft content;
verify they match your business before accepting orders.
