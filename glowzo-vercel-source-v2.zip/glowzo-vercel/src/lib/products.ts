const oil = { url: "/media/oil-cut-700.webp" };
const oilSmall = { url: "/media/oil-cut-360.webp" };
const serum = { url: "/media/serum-cut-700.webp" };
const serumSmall = { url: "/media/serum-cut-360.webp" };
const pack = { url: "/media/pack-cut-700.webp" };
const combo = { url: "/media/combo-offer.webp" };
const packSmall = { url: "/media/pack-cut-360.webp" };

export const BRAND = "GLOWZO";
export const WHATSAPP = "918075981789";

export const products = [
  {
    slug: "brightening-oil",
    name: "Ayurvedic Brightening Oil",
    line: "Glowzo Lite",
    size: "30 ml",
    price: 499,
    img: oil.url,
    smallImg: oilSmall.url,
    ingredients: "Kumkuma, Manjishtha, Kumari, Yashtimadhu, Madhuka, Agnimantha, Patala",
    use: "Apply a few drops 25 minutes before bath, or 3 drops before sleep and wash in the morning.",
    description: "A lightweight Ayurvedic face oil that brightens and evens skin tone. Saffron (Kumkuma) and Manjishtha work with soothing Kumari and Yashtimadhu to bring out a natural, healthy glow.",
  },
  {
    slug: "hair-growth-serum",
    name: "Hair Growth Serum",
    line: "Glowzolite",
    size: "30 ml",
    price: 499,
    img: serum.url,
    smallImg: serumSmall.url,
    ingredients: "Amla, Bhringraj, Rosemary, Castor Oil, Olive Oil, Onion Seed Oil, Vitamin E, Tea Tree Oil",
    use: "Paraben & sulphate free. No added colours or artificial fragrance.",
    description: "A nourishing hair serum built on Amla and Bhringraj, blended with Rosemary, Castor and Onion Seed oils to support stronger, fuller-looking hair from root to tip.",
  },
  {
    slug: "skin-brightening-pack",
    name: "Ayurvedic Skin Brightening Pack",
    line: "Glowzo Lite",
    size: "100 g",
    price: 380,
    img: pack.url,
    smallImg: packSmall.url,
    ingredients: "Njawara, Manjishta, Rose petal powder, Yashtimadhu, Lodhra, Chandana",
    use: "Mix with water into a smooth paste, apply on face and neck for 15–20 minutes, then rinse.",
    description: "A traditional herbal face pack with Njawara, Yashtimadhu and Chandana that gently cleanses, brightens and refreshes dull, tired skin.",
  },
];

export type Product = (typeof products)[number];


export const SHIPPING = 50;

export const comboOffer = {
  slug: "oil-pack-combo",
  name: "Brightening Oil + Skin Brightening Pack Combo",
  line: "Glowzo Lite",
  size: "30 ml + 100 g",
  price: 879,
  img: combo.url,
  smallImg: combo.url,
};

export const catalog = [...products, comboOffer];
