import { ShoppingBag } from "lucide-react";
import { comboOffer } from "@/lib/products";
import { useCart } from "@/lib/cart-context";
import { Button } from "@/components/ui/button";

export function ComboOffer() {
  const { add } = useCart();
  return (
    <div className="mx-auto mt-16 max-w-xl text-center">
      <img src={comboOffer.img} alt="Glowzo Lite Brightening Oil and Skin Brightening Pack combo for ₹879" loading="lazy" decoding="async" width={1000} height={1000} className="w-full rounded-3xl border border-border" />
      <p className="mt-6 font-display text-2xl">{comboOffer.name}</p>
      <p className="mt-1 text-lg">₹{comboOffer.price}</p>
      <Button onClick={() => add(comboOffer.slug)} className="mt-5 h-12 w-full rounded-full text-xs uppercase sm:w-auto sm:px-12">
        <ShoppingBag /> Buy now
      </Button>
    </div>
  );
}
